const btn1 = document.querySelector("#send1");
const btn2 = document.querySelector("#send2");
const btn3 = document.querySelector("#send3");
const btn4 = document.querySelector("#send4");

const e1 = document.querySelector("#n1");
const e2 = document.querySelector("#n2");

var div, mult, sub, soma;

document.addEventListener('contextmenu', event => event.preventDefault());


btn1.addEventListener("click", function(e) {

    e.preventDefault();
    const v1 = e1.value;
    const v2 = e2.value;
    var value1 = parseInt(v1);
    var value2 = parseInt(v2);
    soma = value1 + value2;

    console.log("a soma é " + soma);
    alert("a soma é " + soma);
    document.getElementById("result").innerHTML = "Resultado: " + soma;

});

btn2.addEventListener("click", function(e) {

    e.preventDefault();
    const v1 = e1.value;
    const v2 = e2.value;
    var value1 = parseInt(v1);
    var value2 = parseInt(v2);
    sub = value1 - value2;
    console.log("a subtração é " + sub);
    alert("a subtração é " + sub);
    document.getElementById("result").innerHTML = "Resultado: " + sub;

});

btn3.addEventListener("click", function(e) {

    e.preventDefault();
    const v1 = e1.value;
    const v2 = e2.value;
    var value1 = parseInt(v1);
    var value2 = parseInt(v2);
    mult = value1 * value2;

    console.log("a multiplicação é " + mult);
    alert("a multiplicação é " + mult);
    document.getElementById("result").innerHTML = "Resultado: " + mult;

});

btn4.addEventListener("click", function(e) {

    e.preventDefault();
    const v1 = e1.value;
    const v2 = e2.value;
    var value1 = parseInt(v1);
    var value2 = parseInt(v2);

    div = value1 / value2;

    console.log("a divisao é " + div);
    alert("a divisao é " + div);
    document.getElementById("result").innerHTML = "Resultado: " + div;

});