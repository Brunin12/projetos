var bruno = 0;
var matheus = 0;
var julio = 0;
var icaro = 0;
var helena = 0;
var miguel = 0;
var iasmin = 0;
var enzo = 0;
var gabriel = 0;
var davi = 0;

var img = document.createElement("IMG");
img.src = "img/bruno.jpg";
var canvas = document.getElementById("canvas");
var ctx = canvas.getContext("2d");

const btn = document.querySelector("#send");


document.addEventListener('contextmenu', event => event.preventDefault());


btn.addEventListener("click", function(e) {

    e.preventDefault();

    const name = document.querySelector("#entrada");

    const value = name.value;
    console.log(value);
    show(value)

});

function show(value) {
    if (value == 1502) {
        votar1();
        alert("votou em bruno");
        ctx.fillText("oi", 30, 20);
    } else if (value == 1752) {
        votar2();
        alert("votou em matheus");
    } else if (value == 1544) {
        votar3();
        alert("votou em julio");
    } else if (value == 4562) {
        votar4();
        alert("votou em icaro");
    } else if (value == 1805) {
        votar5();
        alert("votou em helena");
    } else if (value == 1222) {
        votar6();
        alert("votou em miguel");
    } else if (value == 3582) {
        votar7();
        alert("votou em iasmin");
    } else if (value == 1782) {
        votar8();
        alert("votou em enzo");
    } else if (value == 3402) {
        votar9();
        alert("votou em gabriel");
    } else if (value == 2795) {
        votar10();
        alert("votou em davi");
    } else {
        alert("não encontramos o candidato " + value)
    }
}
function votar1() {
    bruno++;
    document.getElementById("bruno").innerHTML = "bruno: " + bruno;
}
function votar2() {
    matheus++;
    document.getElementById("matheus").innerHTML = "matheus: " + matheus;
}

function votar3() {
    julio++;
    document.getElementById("julio").innerHTML = "julio: " + julio;
}

function votar4() {
    icaro++;
    document.getElementById("icaro").innerHTML = "icaro: " + icaro;
}

function votar5() {
    helena++;
    document.getElementById("helena").innerHTML = "helena: " + helena;
}

function votar6() {
    miguel++;
    document.getElementById("miguel").innerHTML = "miguel: " + miguel;
}

function votar7() {
    iasmin++;
    document.getElementById("iasmin").innerHTML = "iasmin: " + iasmin;
}

function votar8() {
    enzo++;
    document.getElementById("enzo").innerHTML = "enzo: " + enzo;
}

function votar9() {
    gabriel++;
    document.getElementById("gabriel").innerHTML = "gabriel: " + gabriel;
}

function votar10() {
    davi++;
    document.getElementById("davi").innerHTML = "davi: " + davi;
}

